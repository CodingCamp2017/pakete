var URL_MAP = {
  ibiss: 'http://localhost:8080/IbissBackend',
  mura: 'http://portaldev.hagel.at/mura'
};

var http = require('http'),
    httpProxy = require('http-proxy'),
    HttpProxyRules = require('http-proxy-rules');

var proxyRules = new HttpProxyRules({
  rules: {
    '.*/IbissBackend': URL_MAP.ibiss,
    '.*/mura': URL_MAP.mura
  },
  default: URL_MAP.mura
});


var proxy = httpProxy.createProxy().on('proxyReq', function(proxyReq) {
  //debug
  //console.log(proxyReq);
});

http.createServer(function(req, res) {
  // a match method is exposed on the proxy rules instance
  // to test a request to see if it matches against one of the specified rules
  var target = proxyRules.match(req);
  if (target) {

    res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.setHeader('Access-Control-Request-Method', '*');
    res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET, POST');
    res.setHeader('Access-Control-Allow-Headers', Object.keys(req.headers).concat(['content-type']));
    res.setHeader('Access-Control-Allow-Credentials', 'true');

    return proxy.web(req, res, {
      target: target
    });
  }

  res.writeHead(500, { 'Content-Type': 'text/plain' });
  res.end('The request url and path did not match any of the listed rules!');
}).listen(6010);
